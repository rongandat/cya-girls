<div class="footer">
    <div class="container">
        <div class="footer-content">
            <div class="row">
                <div class="col-md-4 col-sm-4 logo-footer">
                    <span> <a href="index.html">Restaurant</a></span>
                </div>
                <div class="col-md-4 col-sm-4 footer-info">
                    <div class="col-md-4 col-sm-4">
                        <a href="#">HOME</a>
                    </div>
                    <div class="col-md-4 col-sm-4">
                        <a href="#.team">ABOUT</a>
                    </div>
                    <div class="col-md-4 col-sm-4">
                        <a href="#.contact">CONTACT</a>
                    </div>
                </div>
                <div class="col-md-4 col-sm-4 footer-copyright">
                    <span>  Copyright &copy;<a href="#">Restaurant 2014</a></span>
                </div>
            </div>
        </div>
    </div>
</div>